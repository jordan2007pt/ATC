document.addEventListener("DOMContentLoaded", function() {
    // Mostrar el contenido principal después de que la página cargue
    window.onload = function() {
        document.getElementById('loader').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    };

    // Agregar fotos a la galería
    const addPhotoButton = document.getElementById('add-photo');
    const photoUploadInput = document.getElementById('photo-upload');
    const photoGallery = document.getElementById('photo-gallery');

    addPhotoButton.addEventListener('click', function() {
        const files = photoUploadInput.files;
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                photoGallery.appendChild(img);
            };
            reader.readAsDataURL(file);
        }
    });
});